<div style="margin-top: 40px;"></div>
<footer id='footer' class="panel-footer ">
	<div class="bottom">
		<div class="container">
			<div class="col-md-4">
				<h3><span class="glyphicon glyphicon-heart"></span> About us</h3>
				<p><a href="./">Algorithem Executer V 1.0</a></p>
			</div>
			<div class="col-md-4">
				<h3><span class="glyphicon glyphicon-star"></span> Follow us</h3>
				<p>
				<div class="socailfollow">
				 <a class="twitter" href="#"><i class="icomoon-twitter"></i></a>
				 <a class="facebook" href="#"><i class="icomoon-facebook"></i></a>
				 <a class="youtube" href="#"><i class="icomoon-youtube"></i></a>
				 <a class="linkedin" href="#"><i class="icomoon-linkedin"></i></a>
				 <a class="dribble" href="#"><i class="icomoon-dribbble"></i></a>
				 <a class="pinterest" href="#"><i class="icomoon-pinterest"></i></a>
				 <a class="vimeo" href="#"><i class="icomoon-vimeo"></i></a>
				 <a class="google" href="#"><i class="icomoon-google"></i></a>
				 <a class="rss" href="#"><i class="icomoon-feed-3"></i></a>
					<div class="clear"></div>
				</div>
				</p>
			</div>
			<div class="col-md-4">
				<h3><span class="glyphicon glyphicon-music"></span> Contact us</h3>
				<p>
				<form class="form-group" action="#">
					<input name="emailTo" type="hidden" value="info@assurancegroup.co.uk">
					<input class="form-control" name="txtName" id="txtName" type="text" placeholder="Your Name..." value="">
					<input class="form-control" name="txtEmail" id="txtEmail" type="text" placeholder="Your Email Address..." value="">
					<textarea class="form-control" name="txtText" id="txtText" placeholder="Your Message...">Your Message...</textarea>
					<button class="btn btn-default" type="button">SEND MESSAGE</button>
					<div id="spanMessage"></div>
				</form>
			</div>
			</p>
		</div>
	</div>
	</div>
</footer>
</body></html>